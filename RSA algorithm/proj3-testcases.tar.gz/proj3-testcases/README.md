namelist.txt -- the "student" ids
task1-keys.json -- keys for task1
task2-keys.json -- keys for task2
task3-keys.json -- keys for task3
batman-submission.txt -- submission.txt for batman
ironman-submission.txt -- submission.txt for ironman
spiderman-submission.txt -- submission.txt for spiderman
superman-submission.txt -- submission.txt for superman
