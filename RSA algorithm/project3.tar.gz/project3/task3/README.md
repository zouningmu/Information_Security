#Where is Waldo?#

You're given a public key P, find your Waldo among your classmates and get P's private key.
Complete the 2 TODOs in "find_waldo.py".

Submission:
1. private key, in hex format.
2. your waldo.
3. find_waldo.py.
4. your understanding about the weak key problem.
5. a brief explanation about how you get the private key.
